package it.unica.pr2.biblioteca;

import it.unica.pr2.biblioteca.libreria.Libro;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.Iterator;

public class Biblioteca extends ArrayList<Libro> {

	private String nessun_libro;
	private int num_libri;

	public Biblioteca(Libro[] list){
		if( list.length <= 0){
			this.num_libri = 0;
			this.nessun_libro = "Nessun libro presente.";
		}else{	
			this.add(list[0]);
			this.add(list[1]);
		}
	}

	@Override
	public String toString(){
	if(num_libri == 0){ 		
		return this.nessun_libro;	
	}else{
		Iterator<Libro> LibriIterator = this.iterator();
		String answer = null;
		while (LibriIterator.hasNext()) {
			answer += LibriIterator.next().toString();
		}
				return answer;	
		}

	}
	
	public int pagine(){
		return this.stream().mapToInt(Libro::getPag).sum();
	}	

}
