package finanza;

public class ConvertiEuro {

	
	private int count;
	Valuta[] valute;
	
	public ConvertiEuro(){
		valute = new Valuta[3];
		count = 0;
	}
	
	public boolean impostaValuta(Valuta val){
		if(count != 3){
				this.valute[count] = val;
				count++;		
				return true;
		}else
			return false;
	}

/*	
	@Override
	public String toString(){

	
	
		return "[ (" + this.name + ", " + this.num]";		
	}
	*/
		
	public double converti(Double num, String name){
	
		return 1;
	}


}
