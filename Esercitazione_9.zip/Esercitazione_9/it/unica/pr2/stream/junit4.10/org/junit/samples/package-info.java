/**
 * Provides examples on how to use JUnit 4.
 *
 * @since 4.0
 */
package org.junit.samples;