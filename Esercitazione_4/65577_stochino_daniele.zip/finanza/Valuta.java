package finanza;

public class Valuta {


	Double val;
	String name;
	
	public Valuta(String name, Double val){
		this.val = val;
		this.name = name;
	}
}

